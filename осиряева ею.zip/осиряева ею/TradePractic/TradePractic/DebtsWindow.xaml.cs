﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TradePractic
{
    /// <summary>
    /// Логика взаимодействия для DebtsWindow.xaml
    /// </summary>
    public partial class DebtsWindow : Window
    {
        private TradeDBEntities context;
        private int clientId;
        private Debts currentDebt;
        public DebtsWindow(int selectedClientId)
        {
            InitializeComponent();
            context = new TradeDBEntities();
            clientId = selectedClientId;
            LoadDebtInfo();
        }
        private void LoadDebtInfo()
        {
            var client = context.Clients.Find(clientId);
            tbClientInfo.Text = $"Клиент: {client.ClientName}";
            currentDebt = context.Debts.FirstOrDefault(d => d.ClientId == clientId);
            if (currentDebt != null)
            {
                tbDebtAmount.Text = $"{currentDebt.Amount:C}";
                btnCollectMoney.IsEnabled = true;
                var today = DateTime.Today;
                var endOfMonth = new DateTime(today.Year, today.Month, DateTime.DaysInMonth(today.Year, today.Month));
                var daysLeft = (endOfMonth - today).Days;
                tbDaysLeft.Text = $"До конца месяца осталось: {daysLeft} дней";
            }
            else
            {
                tbDebtAmount.Text = "Нет задолженности";
                tbDaysLeft.Text = "Клиент без долгов";
                btnCollectMoney.IsEnabled = false;
            }
        }
        private void BtnCollectMoney_Click(object sender, RoutedEventArgs e)
        {
            if (decimal.TryParse(txtPaymentAmount.Text, out decimal paymentAmount) && paymentAmount > 0)
            {
                if (currentDebt != null)
                {
                    if (paymentAmount <= currentDebt.Amount)
                    {
                        currentDebt.Amount -= paymentAmount;
                        currentDebt.LastUpdate = DateTime.Today;

                        context.SaveChanges();
                        MessageBox.Show($"Оплата принята! Остаток долга: {currentDebt.Amount} руб.");
                        LoadDebtInfo();
                        txtPaymentAmount.Clear();
                    }
                    else
                    {
                        MessageBox.Show("Сумма оплаты не может превышать долг");
                    }
                }
            }
            else
            {
                MessageBox.Show("Введите корректную сумму оплаты");
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
