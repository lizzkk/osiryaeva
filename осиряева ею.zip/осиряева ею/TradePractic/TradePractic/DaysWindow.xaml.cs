﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TradePractic
{
    /// <summary>
    /// Логика взаимодействия для DaysWindow.xaml
    /// </summary>
    public partial class DaysWindow : Window
    {
        private TradeDBEntities context;
        public DaysWindow()
        {
            InitializeComponent();
            context = new TradeDBEntities();
        }
        private void DayButton_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            int selectedDistrictId = int.Parse(button.Tag.ToString());
            var fuelWindow = new FuelWindow(selectedDistrictId);
            if (fuelWindow.ShowDialog() == true)
            {
                var clientsWindow = new ClientsWindow(selectedDistrictId);
                clientsWindow.ShowDialog();
            }
            this.Close();
        }
    }
}
