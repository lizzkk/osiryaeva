﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TradePractic
{
    /// <summary>
    /// Логика взаимодействия для FuelWindow.xaml
    /// </summary>
    public partial class FuelWindow : Window
    {
        private TradeDBEntities context;
        public int districtId;
        public Districts district;
        public FuelWindow(int selectedDistrictId)
        {
            InitializeComponent();
            context = new TradeDBEntities();
            districtId = selectedDistrictId;
            LoadDistrictInfo();
        }
        private void LoadDistrictInfo()
        {
            district = context.Districts.Find(districtId);
            tbDistrictInfo.Text = $"Район: {district.DistrictName}\nТребуется заправить: {district.FuelRequired} литров";
        }
        private void BtnContinue_Click(object sender, RoutedEventArgs e)
        {
            if (decimal.TryParse(txtActualFuel.Text, out decimal actualFuel))
            {
                var fuelUsage = new FuelUsage
                {
                    DistrictId = districtId,
                    PlannedFuel = district.FuelRequired,
                    ActualFuel = actualFuel,
                    UsageDate = DateTime.Today
                };
                context.FuelUsage.Add(fuelUsage);
                context.SaveChanges();

                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Введите корректное количество бензина");
            }
        }
        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
