﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TradePractic
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnFuelReport_Click(object sender, RoutedEventArgs e)
        {
            var fuelReportWindow = new FuelReportWindow();
            fuelReportWindow.ShowDialog();
        }

        private void BtnViewClients_Click(object sender, RoutedEventArgs e)
        {
            var clientsWindow = new ClientsWindow();
            clientsWindow.ShowDialog();
        }

        private void BtnViewProducts_Click(object sender, RoutedEventArgs e)
        {
            var productsWindow = new ProductsWindow();
            productsWindow.ShowDialog();
        }

        private void BtnLoadData_Click(object sender, RoutedEventArgs e)
        {
            var daysWindow = new DaysWindow();
            daysWindow.ShowDialog();
        }
    }
}
