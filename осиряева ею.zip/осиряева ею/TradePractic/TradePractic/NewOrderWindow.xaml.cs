﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TradePractic
{
    /// <summary>
    /// Логика взаимодействия для NewOrderWindow.xaml
    /// </summary>
    public partial class NewOrderWindow : Window
    {
        private TradeDBEntities context;
        private int clientId;
        private List<OrderItem> orderItems;
        public class OrderItem
        {
            public int ProductId { get; set; }
            public string ProductName { get; set; }
            public decimal Price { get; set; }
            public int Quantity { get; set; }
            public decimal Total => Price * Quantity;
        }
        public NewOrderWindow(int selectedClientId)
        {
            InitializeComponent();
            context = new TradeDBEntities();
            clientId = selectedClientId;
            orderItems = new List<OrderItem>();
            LoadClientInfo();
            LoadProducts();
            UpdateOrderSummary();
        }
        private void LoadClientInfo()
        {
            var client = context.Clients.Find(clientId);
            tbClientInfo.Text = $"Новый заказ для: {client.ClientName}";
        }
        private void LoadProducts()
        {
            var products = context.Products.Where(p => p.Quantity > 0).ToList();
            lvProducts.ItemsSource = products;
        }
        private void LvProducts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lvProducts.SelectedItem is Products selectedProduct)
            {
                tbSelectedProduct.Text = $"{selectedProduct.ProductName} - {selectedProduct.Price:C}";
            }
        }
        private void BtnAddToOrder_Click(object sender, RoutedEventArgs e)
        {
            if (lvProducts.SelectedItem is Products selectedProduct && int.TryParse(txtQuantity.Text, out int quantity) && quantity > 0)
            {
                if (quantity <= selectedProduct.Quantity)
                {
                    var existingItem = orderItems.FirstOrDefault(oi => oi.ProductId == selectedProduct.ProductId);
                    if (existingItem != null)
                    {
                        existingItem.Quantity += quantity;
                    }
                    else
                    {
                        orderItems.Add(new OrderItem
                        {
                            ProductId = selectedProduct.ProductId,
                            ProductName = selectedProduct.ProductName,
                            Price = selectedProduct.Price,
                            Quantity = quantity
                        });
                    }

                    lvOrderItems.ItemsSource = null;
                    lvOrderItems.ItemsSource = orderItems;
                    UpdateOrderSummary();
                    txtQuantity.Clear();
                }
                else
                {
                    MessageBox.Show($"Недостаточно товара на складе. В наличии: {selectedProduct.Quantity}");
                }
            }
            else
            {
                MessageBox.Show("Выберите товар и введите корректное количество");
            }
        }
        private void UpdateOrderSummary()
        {
            decimal total = orderItems.Sum(oi => oi.Total);
            tbTotalAmount.Text = $"Итого: {total:C}";
        }
        private void BtnCreateOrder_Click(object sender, RoutedEventArgs e)
        {
            if (!orderItems.Any())
            {
                MessageBox.Show("Добавьте товары в заказ");
                return;
            }

            try
            {
                var order = new Orders 
                {
                    ClientId = clientId,
                    OrderDate = DateTime.Today,
                    TotalAmount = orderItems.Sum(oi => oi.Total)
                };
                context.Orders.Add(order);
                context.SaveChanges();

                foreach (var item in orderItems)
                {
                    var orderDetail = new OrderDetails
                    {
                        OrderId = order.OrderId,
                        ProductId = item.ProductId,
                        Quantity = item.Quantity,
                        Price = item.Price
                    };
                    context.OrderDetails.Add(orderDetail);

                    var product = context.Products.Find(item.ProductId);
                    product.Quantity -= item.Quantity;
                }

                var existingDebt = context.Debts.FirstOrDefault(d => d.ClientId == clientId);
                if (existingDebt != null)
                {
                    // Если долг уже есть - увеличиваем его
                    existingDebt.Amount += order.TotalAmount;
                    existingDebt.LastUpdate = DateTime.Today;
                }
                else
                {
                    // Если долга нет - создаем новый
                    var newDebt = new Debts
                    {
                        ClientId = clientId,
                        Amount = order.TotalAmount,
                        LastUpdate = DateTime.Today
                    };
                    context.Debts.Add(newDebt);
                }

                context.SaveChanges();
                MessageBox.Show($"Заказ успешно создан! Сумма заказа: {order.TotalAmount} руб. добавлена в долг клиента");
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка создания заказа: {ex.Message}");
            }
        }
        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
