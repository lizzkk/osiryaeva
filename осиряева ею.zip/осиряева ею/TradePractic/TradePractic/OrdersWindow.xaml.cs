﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TradePractic
{
    /// <summary>
    /// Логика взаимодействия для OrdersWindow.xaml
    /// </summary>
    public partial class OrdersWindow : Window
    {
        private TradeDBEntities context;
        private int clientId;
        public OrdersWindow(int selectedClientId)
        {
            InitializeComponent();
            context = new TradeDBEntities();
            clientId = selectedClientId;
            LoadOrders();
        }
        private void LoadOrders()
        {
            try
            {
                var client = context.Clients.Find(clientId);
                tbHeader.Text = $"Заказы клиента: {client.ClientName}";

                var orders = context.Orders
                    .Where(o => o.ClientId == clientId)
                    .OrderByDescending(o => o.OrderDate)
                    .ToList();

                lvOrders.ItemsSource = orders;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заказов: {ex.Message}");
            }
        }
        private void LvOrders_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lvOrders.SelectedItem is Orders selectedOrder)
            {
                try
                {
                    var orderDetails = context.OrderDetails
                        .Where(od => od.OrderId == selectedOrder.OrderId)
                        .Include(od => od.Products)
                        .ToList();

                    if (orderDetails.Any())
                    {
                        string details = string.Join("\n", orderDetails.Select(od =>
                            $"{od.Products.ProductName}: {od.Quantity} x {od.Price:C} = {od.Quantity * od.Price:C}"));

                        MessageBox.Show($"Детали заказа #{selectedOrder.OrderId}:\n\n{details}",
                                      "Детали заказа", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки деталей: {ex.Message}");
                }
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
