﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TradePractic
{
    /// <summary>
    /// Логика взаимодействия для FuelReportWindow.xaml
    /// </summary>
    public partial class FuelReportWindow : Window
    {
        private TradeDBEntities context;
        public FuelReportWindow()
        {
            InitializeComponent();
            context = new TradeDBEntities();
            LoadFuelReport();
        }
        private void LoadFuelReport()
        {
            var fuelUsage = context.FuelUsage
                .OrderByDescending(f => f.UsageDate)
                .ToList();

            lvFuelUsage.ItemsSource = fuelUsage;
        }
        private void BtnSendMessage_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtFuelMessage.Text))
            {
                MessageBox.Show($"Сообщение отправлено администратору:\n\n{txtFuelMessage.Text}",
                              "Сообщение отправлено", MessageBoxButton.OK, MessageBoxImage.Information);
                txtFuelMessage.Clear();
            }
            else
            {
                MessageBox.Show("Введите текст сообщения");
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
