﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TradePractic
{
    /// <summary>
    /// Логика взаимодействия для ClientsWindow.xaml
    /// </summary>
    public partial class ClientsWindow : Window
    {
        private TradeDBEntities context;
        private int? districtId;
        public ClientsWindow(int? selectedDistrictId = null)
        {
            InitializeComponent();
            context = new TradeDBEntities();
            districtId = selectedDistrictId;
            LoadClients();
        }
        private void LoadClients()
        {
            try
            {
                var clients = context.Clients.AsQueryable();
                if (districtId.HasValue)
                {
                    clients = clients.Where(c => c.DistrictId == districtId.Value);
                    var district = context.Districts.Find(districtId.Value);
                    tbHeader.Text = $"Клиенты района: {district.DistrictName}";
                }
                else
                {
                    clients = clients.OrderBy(c => c.Districts.DistrictName);
                    tbHeader.Text = "Все клиенты";
                }
                lvClients.ItemsSource = clients.ToList();
            }
            catch (Exception ex) 
            {
                MessageBox.Show($"Ошибка загрузки клиентов: {ex.Message}");
            }
        }
        private void BtnSelectClient_Click(object sender, RoutedEventArgs e)
        {
            if (lvClients.SelectedItem is Clients selectedClient)
            {
                var clientActionsWindow = new ClientActionsWindow(selectedClient.ClientId);
                clientActionsWindow.ShowDialog();
                LoadClients();
            }
            else
            {
                MessageBox.Show("Выберите клиента из списка");
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
