﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TradePractic
{
    /// <summary>
    /// Логика взаимодействия для ClientActionsWindow.xaml
    /// </summary>
    public partial class ClientActionsWindow : Window
    {
        private TradeDBEntities context;
        public int clientId;
        public ClientActionsWindow(int selectedClientId)
        {
            InitializeComponent();
            context = new TradeDBEntities();
            clientId = selectedClientId;
            LoadClientInfo();
        }
        private void LoadClientInfo()
        {
            var client = context.Clients.Find(clientId);
            if (client != null)
            {
                tbClientInfo.Text = $"Клиент: {client.ClientName}\nАдрес: {client.Address}\nТелефон: {client.Phone}";
            }
        }
        private void BtnViewOrders_Click(object sender, RoutedEventArgs e)
        {
            var ordersWindow = new OrdersWindow(clientId);
            ordersWindow.ShowDialog();
        }
        private void BtnViewDebts_Click(object sender, RoutedEventArgs e)
        {
            var debtsWindow = new DebtsWindow(clientId);
            debtsWindow.ShowDialog();
            LoadClientInfo();
        }
        private void BtnNewOrder_Click(object sender, RoutedEventArgs e)
        {
            var newOrderWindow = new NewOrderWindow(clientId);
            if (newOrderWindow.ShowDialog() == true)
            {
                MessageBox.Show("Заказ успешно создан!");
            }
        }
    }
}
